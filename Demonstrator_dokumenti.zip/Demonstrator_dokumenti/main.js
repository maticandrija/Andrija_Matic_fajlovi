let form = document.querySelector('form');

let ime = document.getElementById('ime');
let poruka = document.getElementById('poruka');
let email = document.getElementById('email'); 
let Godinarodjenja = document.getElementById('dob');

form.addEventListener('submit', function(e){
    e.preventDefault();

    localStorage.setItem('ime', ime.value);
    localStorage.setItem('email', email.value);
    localStorage.setItem('poruka',poruka.value);
    localStorage.setItem('Godinarodjenja',dob.value);

    console.log(localStorage.getItem('ime'));
    console.log(localStorage.getItem('poruka'));
    console.log(localStorage.getItem('email'));
    console.log(localStorage.getItem('dob'));
});