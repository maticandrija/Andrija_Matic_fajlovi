<?php
if(isset(%_POST['submit'])){
    $file = "data.json";
    $arr = array(
        'ime'      => $_POST['ime'],
        'poruka'   => $_POST['poruka'],
        'email'    => $_POST['email'],
        'birthday' => $_POST['dob']
    );
    $json_string = json_encode($arr);
    file_put_contents($file,$json_string);
    echo $json_string;
}
?>
<!doctype html>
<html>
<head>
</head>
<body>
<div style = "text-align:center;">
<form name = "form1" id="form1" method="post" action="">
                    <label for="ime">Vase ime i prezime</label>
                    <input required type="text" name="ime" placeholder="ime i prezime" autofocus required>
                    <label for="email" >Vas e-mail:</label>
                    <input required type="email" name="e-mail" placeholder="vasmajl@primer.com" />
                    <label for="poruka">Vasa poruka:</label>
                    <textarea required name= "poruka" placeholder="vasa poruka" rows="4"></textarea>
                    <label for="dob"> Godina rodjenja:</label>
                    <input type="date" name="dob" id="dob">
                    <button type="submit">Posalji</button>
                    </form>
</div>
</body>
</html>

